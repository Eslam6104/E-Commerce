import React from 'react'

function Checkout() {
  return (
    <div>
      Checkout
    </div>
  )
}

export default Checkout
