import React, { useState } from "react";
import { Navbar, Nav, Container } from "react-bootstrap";
import { Search, User, ShoppingBag, Menu } from "lucide-react";
import "./GarderobeNavba.css";

const links = ["Home", "Products", "Services", "About Us", "News", "Contact"];

const GarderobeNavbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <Navbar className="garderobe-navbar" fixed="top">
      <Container fluid className="garderobe-navbar-inner">
        {/* Logo */}
        <Navbar.Brand href="#" className="logo">
          <span className="logo-icon">G</span>
          <span className="logo-text">arderobe</span>
        </Navbar.Brand>

        {/* Center links (desktop only) */}
        <Nav className="desktop-nav">
          {links.map((label) => (
            <Nav.Link
              key={label}
              href="#"
              className={label === "Products" ? "active" : ""}
            >
              {label}
            </Nav.Link>
          ))}
        </Nav>

        {/* Right icons (desktop only) */}
        <div className="desktop-icons">
          <button className="icon-btn" aria-label="Search">
            <Search size={18} />
          </button>
          <button className="icon-btn" aria-label="Account">
            <User size={18} />
          </button>
          <button className="icon-btn" aria-label="Cart">
            <ShoppingBag size={18} />
          </button>
        </div>

        {/* Right side (mobile) */}
        <div className="mobile-right">
          <button className="icon-btn" aria-label="Cart">
            <ShoppingBag size={20} />
          </button>
          <button
            className="icon-btn"
            aria-label="Toggle navigation"
            onClick={() => setOpen((prev) => !prev)}
          >
            <Menu size={22} />
          </button>
        </div>
      </Container>

      {/* Expandable menu (mobile) */}
      <div className={`mobile-nav ${open ? "open" : ""}`}>
        {links.map((label) => (
          <button
            key={label}
            className={`mobile-link ${label === "Products" ? "active" : ""}`}
            onClick={() => setOpen(false)}
          >
            {label}
          </button>
        ))}
      </div>
    </Navbar>
  );
};

export default GarderobeNavbar;
