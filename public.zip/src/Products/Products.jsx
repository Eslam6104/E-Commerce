import React from "react";
function Products() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Products</h1>
      <p>This is the Products page. You can build your product list here.</p>
    </div>
  );
}

export default Products;
