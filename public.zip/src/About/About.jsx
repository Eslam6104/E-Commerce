import React from 'react'

function About() {
  return (
    <div>
      about us
    </div>
  )
}

export default About
