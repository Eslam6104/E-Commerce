import { useState } from "react";
import Nav from "./Components/Nav.jsx";
import Footer from "./Components/footer/Footer.jsx";
import { Routes, Route } from "react-router-dom";
import Service from "./Service/Service.jsx";
import Contact from "./Contact/Contact.jsx";
import New from "./News/New.jsx";
import Home from "./Home/Home.jsx";
import Products from "./Products/Products.jsx";
import Signin from "./LogReg/Signin.jsx";
import Signup from "./LogReg/Signup.jsx";
function App() {
  return (
    <>
      <Nav />
      <Routes>
        {/* home */}
        <Route path="/" element={<Home />} />
        {/* sign in /up*/}
        <Route path="/signin" element={<Signin />} />
        <Route path="/signup" element={<Signup />} />
        {/* news */}
        <Route path="/new" element={<New />} />
        {/* product */}
        <Route path="/Products" element={<Products />} />
        {/* service */}
        <Route path="/service" element={<Service />} />
        {/* Contact */}

        <Route path="/contact" element={<Contact />} />

        {/* not found page */}
        <Route path="*" element={<h1>Page Not Found</h1>} />
      </Routes>
      <Footer />
    </>
  );
}

export default App;
