import { useState } from 'react'
import GarderobeNavba from './Components/Nav'
function App() {
 

  return (
    <>
<GarderobeNavba />
 
   </>
  )
}

export default App
