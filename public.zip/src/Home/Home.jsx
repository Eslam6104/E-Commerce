import React from 'react'
import Card from '../Components/Card/Card'
function Home() {
  return (
  <Card/>
  )
}

export default Home
