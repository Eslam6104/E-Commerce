import React from 'react'

function Service() {
  return (
    <div>
      Service
    </div>
  )
}

export default Service
