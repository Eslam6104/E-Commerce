import React from "react";

function Cart() {
  return <div>Cart page</div>;
}

export default Cart;