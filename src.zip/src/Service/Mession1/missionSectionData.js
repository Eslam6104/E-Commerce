export const missionSectionData = {
  tag: "OUR MISSION",
  title: "Your Personal Styling Team Always Here",
  description:
    "Integer at faucibus urna. Nullam condimentum leo id elit sagittis auctor. Curabitur elementum nunc a leo imperdiet, nec elementum diam elementum. Etiam elementum euismod commodo. Proin eleifend eget quam ut efficitur. Mauris a accumsan mauris. Phasellus egestas et risus sit amet hendrerit. Nulla facilisi.",
  buttonText: "MORE DETAILS",
  buttonLink: "/News",
  image:
    "https://res.cloudinary.com/dah254u09/image/upload/v1764340198/WhatsApp_Image_2025-11-28_at_3.33.33_PM_vqmrji.jpg",
};
