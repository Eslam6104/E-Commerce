import Logo from "../Nav/Logo";

function FooterMiddle() {
  return (
    <div className="border-top">
      <div className="container py-4 justify-content-center d-flex">
        <Logo />
      </div>
    </div>
  );
}
export default FooterMiddle;