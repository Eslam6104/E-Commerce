import React from "react";
import { useParams } from "react-router-dom";
import { useGetProductsQuery } from "../Store/apislice";
import { parseProductSlug } from "../Components/slug";
function ProductPage() {
  const { slug } = useParams();
  const { data: products, isLoading, isError } = useGetProductsQuery();

  if (isLoading) {
    return (
      <div className="container py-5">
        <h2>Loading product...</h2>
      </div>
    );
  }

  if (isError || !Array.isArray(products)) {
    return (
      <div className="container py-5">
        <h2>Error loading product.</h2>
      </div>
    );
  }

  const { id, title } = parseProductSlug(slug);

  let product = null;

  if (id) {
    product = products.find((p) => p.id === id);
  }

  if (!product && title) {
    const t = title.toLowerCase();
    product = products.find((p) => p.title.toLowerCase() === t);
  }

  if (!product) {
    return (
      <div className="container py-5">
        <h2>Product not found</h2>
        <p className="text-muted">
          We couldn&apos;t find a product matching this URL.
        </p>
      </div>
    );
  }

  return (
    <div className="container py-5">
      <div className="row g-4">
        {/* الصورة */}
        <div className="col-12 col-md-4">
          <div className="border rounded p-3 text-center bg-light">
            <img
              src={product.thumbnail}
              alt={product.title}
              className="img-fluid"
              style={{ maxHeight: "260px", objectFit: "contain" }}
            />
          </div>
        </div>

        {/* التفاصيل */}
        <div className="col-12 col-md-8">
          <h2 className="fw-bold mb-2">{product.title}</h2>

          <p className="text-muted mb-2">
            Category: <strong>{product.category}</strong>
          </p>

          <p className="mb-2">
            <span style={{ color: "gold", fontSize: "18px" }}>
              {"★".repeat(Math.round(product.rating ?? 0))}
            </span>{" "}
            <span className="text-muted small">
              {product.rating?.toFixed?.(1) ?? product.rating ?? ""}
            </span>
          </p>

          <h3 className="text-success mb-3">${product.price}</h3>

          <p className="mb-3">{product.description}</p>

          <p className="mb-3">
            <strong>Status: </strong>
            {product.stock > 0 ? (
              <span className="text-success">In stock ({product.stock})</span>
            ) : (
              <span className="text-danger">Out of stock</span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}

export default ProductPage;
