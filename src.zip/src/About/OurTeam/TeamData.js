export const teamData = [
  {
    name: "omar ayuob",
    role: "react developer",
    image: "https://res.cloudinary.com/dah254u09/image/upload/v1764340198/WhatsApp_Image_2025-11-28_at_3.33.33_PM_vqmrji.jpg",
  },
  {
    name: "Roger Jones",
    role: "react developer",
    image: "https://res.cloudinary.com/dah254u09/image/upload/v1764319826/1740522005569_d8fcr5.jpg",
  },
  {
    name: "eslam amer",
    role: "react developer",
    image: "https://res.cloudinary.com/dah254u09/image/upload/v1764327546/1720132437869_dsz1ee.jpg",
  },

];
